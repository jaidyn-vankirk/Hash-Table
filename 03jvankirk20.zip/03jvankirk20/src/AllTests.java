import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * 
 * Runs both of our tests at the same time.
 * @author jaidynvankirk
 *
 */
@RunWith(Suite.class)
@SuiteClasses({ HiggsTest.class, JaidynsTest.class })
public class AllTests {

}
