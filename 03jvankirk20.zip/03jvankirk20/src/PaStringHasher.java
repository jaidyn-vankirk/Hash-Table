
/**
 * 
 * Element that hashes keys by using Horner's method.
 * @author jaidynvankirk
 *
 */
public class PaStringHasher implements Hasher{

	public int hashKey(String key, int maxNumberOfBuckets) {
		byte[] stringVals = key.getBytes();
		int max = maxNumberOfBuckets;
		int hash = 0;
		for (int i = 0; i < stringVals.length; i ++) {
			hash = (hash * 33 + stringVals[i])%max;
		}
		return hash;
	}

}
