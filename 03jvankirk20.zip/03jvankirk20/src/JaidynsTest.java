import static org.junit.Assert.*;

import org.junit.Test;
	/**
	 * Tests the QuadraticHashTable and the PaStringHasher
	 * @author jaidynvankirk
	 *
	 */
public class JaidynsTest {
	
	@Test
	public void QuadraticHashTableAndSlotsGetterTest() {
		PaStringHasher hash = new PaStringHasher();
		QuadraticHashTable h = new QuadraticHashTable(hash, 23);
		assertTrue(h.getSlots() == 23 && h.elements.length == 23);
		h = new QuadraticHashTable(hash, 50);
		assertTrue(h.getSlots() == 50 && h.elements.length == 50);
	}
	
	@Test
	public void SizeTest() {
		PaStringHasher hash = new PaStringHasher();
		QuadraticHashTable h = new QuadraticHashTable(hash, 23);
		Object Texas = new Object();
		h.put("Tx", Texas);
		assertTrue(h.size() == 1);
		Object California = new Object();
		h.put("Ca", California);
		Object Alabama = new Object();
		assertTrue(h.size() == 2);
		h.put("Al",Alabama);
		assertTrue(h.size() == 3);
		Object NewJersey = new Object();
		h.put("Nj", NewJersey);
		assertTrue(h.size() == 4);
		
		h.remove("Tx");
		assertTrue(h.size() == 3);
		h.remove("Tx");
		assertTrue(h.size() == 3);
		
		h.put("Tx", Texas);
		h.put("Tx", Texas);
		assertTrue(h.size() == 5);
	}
	
	@Test
	public void IsEmptyTest() {
		PaStringHasher hash = new PaStringHasher();
		QuadraticHashTable h = new QuadraticHashTable(hash, 23);
		assertTrue(h.isEmpty());
		Object Texas = new Object();
		h.put("Tx", Texas);
		assertFalse(h.isEmpty());
		
		Object California = new Object();
		h.put("Ca", California);
		Object Alabama = new Object();
		h.put("Al",Alabama);
		Object NewJersey = new Object();
		h.put("Nj", NewJersey);
		assertFalse(h.isEmpty());
		h.clear();
		assertTrue(h.isEmpty());
	}
	
	@Test
	public void ValuesAndKeysTest() {						//Need to make sure they line up for my Expand Table method
		PaStringHasher hash = new PaStringHasher();
		QuadraticHashTable h = new QuadraticHashTable(hash, 23);
		Object Texas = new Object();
		h.put("Tx", Texas);
		Object California = new Object();
		h.put("Ca", California);
		Object Alabama = new Object();
		h.put("Al",Alabama);
		Object NewJersey = new Object();
		h.put("Nj", NewJersey);
		Object[] tester = h.values();
		String[] stringTester = h.keys();
		System.out.println("1");
		for(int i = 0; i < tester.length; i++) {
			if(tester[i] == Texas) {
				System.out.println("Texas");
			} else if(tester[i] == Alabama) {
				System.out.println("Alabama");
			} else if(tester[i] == California) {
				System.out.println("California");
			} else if(tester[i] == NewJersey) {
				System.out.println("New Jersey");
			}
			System.out.println(stringTester[i]);
		}
		
		h.remove("Al");
		tester = h.values();
		stringTester = h.keys();
		System.out.println("2");
		for(int i = 0; i < tester.length; i++) {
			if(tester[i] == Texas) {
				System.out.println("Texas");
			} else if(tester[i] == Alabama) {
				System.out.println("Alabama");
			} else if(tester[i] == California) {
				System.out.println("California");
			} else if(tester[i] == NewJersey) {
				System.out.println("New Jersey");
			}
			System.out.println(stringTester[i]);
		}
	}
	
	@Test
	public void GetTest() {
		PaStringHasher hash = new PaStringHasher();
		QuadraticHashTable h = new QuadraticHashTable(hash, 23);
		Object Texas = new Object();
		h.put("Tx", Texas);
		Object California = new Object();
		h.put("Ca", California);
		Object Alabama = new Object();
		h.put("Al",Alabama);
		Object NewJersey = new Object();
		h.put("Nj", NewJersey);
		assertTrue(h.get("Tx") == Texas);
		assertTrue(h.get("Ca") == California);
		assertTrue(h.get("Al") == Alabama);
		assertTrue(h.get("Nj") == NewJersey);
		
		Object Texas2 = new Object();
		h.put("Tx", Texas2);
		h.remove("Tx");
		assertTrue(h.get("Tx") == Texas2);
	}
	
	@Test
	public void PutAndHashKeyTest() {
		PaStringHasher ha = new PaStringHasher();
		QuadraticHashTable h = new QuadraticHashTable(ha, 23);
		Object Texas = new Object();
		Object Texas2 = new Object();
		Object Texas3 = new Object();
		h.put("Tx", Texas);
		int hash = 0;
		String tx = "Tx";
		byte[] stringVals = tx.getBytes();
		for (int i = 0; i < stringVals.length; i ++) {
			hash = (hash * 33 + stringVals[i])%23;
		}
		assertTrue(h.elements[hash].getValue() == Texas);
		h.put("Tx", Texas2);
		assertTrue(h.elements[hash+1].getValue() == Texas2);
		h.put("Tx", Texas3);
		hash = (int) (((hash) + Math.pow(-1, (2 + 1)) * Math.pow(2, 2)) % 23);
		assertTrue(h.elements[hash].getValue() == Texas3);
	}
	
	@Test
	public void RemoveTest() {
		PaStringHasher ha = new PaStringHasher();
		QuadraticHashTable h = new QuadraticHashTable(ha, 23);
		Object Texas = new Object();
		Object Texas2 = new Object();
		Object Texas3 = new Object();
		h.put("Tx", Texas);
		h.put("Tx", Texas2);
		h.put("Tx", Texas3);
		assertTrue(h.size() == 3);
		h.remove("Tx");
		assertTrue(h.size() == 2);
		h.remove("Tx");
		assertTrue(h.size() == 1);
		h.remove("Tx");
		assertTrue(h.size()== 0);
		
		h.put("Tx", Texas);
		Object California = new Object();
		h.put("Ca", California);
		Object Alabama = new Object();
		h.put("Al",Alabama);
		Object NewJersey = new Object();
		h.put("Nj", NewJersey);
		h.remove("Nj");
		Object[] tester = h.values();
		System.out.println("Remove Test 1 - Should print Texas, Alabama, and California");
		for(int i = 0; i < tester.length; i++) {
			if(tester[i] == Texas) {
				System.out.println("Texas");
			} else if(tester[i] == Alabama) {
				System.out.println("Alabama");
			} else if(tester[i] == California) {
				System.out.println("California");
			}
		}
		h.remove("Al");
		tester = h.values();
		System.out.println("Remove Test 2 - Should print Texas and California");
		for(int i = 0; i < tester.length; i++) {
			if(tester[i] == Texas) {
				System.out.println("Texas");
			} else if(tester[i] == California) {
				System.out.println("California");
			}
		}
		h.remove("Ca");
		tester = h.values();
		System.out.println("Remove Test 3 - Should print Texas");
		for(int i = 0; i < tester.length; i++) {
			if(tester[i] == Texas) {
				System.out.println("Texas");
			}
		}
	}
	
	@Test
	public void ClearTest() {
		PaStringHasher ha = new PaStringHasher();
		QuadraticHashTable h = new QuadraticHashTable(ha, 23);
		Object Texas = new Object();
		Object Texas2 = new Object();
		Object Texas3 = new Object();
		h.put("Tx", Texas);
		h.put("Tx", Texas2);
		h.put("Tx", Texas3);
		Object California = new Object();
		h.put("Ca", California);
		Object Alabama = new Object();
		h.put("Al",Alabama);
		Object NewJersey = new Object();
		h.put("Nj", NewJersey);
		assertTrue(h.size() == 6);
		h.clear();
		assertTrue(h.size() == 0);
	}
	
	@Test
	public void ExpandTableTest() {
		PaStringHasher ha = new PaStringHasher();
		QuadraticHashTable h = new QuadraticHashTable(ha, 23);
		Object Texas = new Object();
		for(int i = 0; i < 13; i ++) {
			h.put("Tx", Texas);
			assertTrue(h.size() == i+1);
		}
		h.put("Tx", Texas);
		System.out.println(h.slots + " - Expand table number");
		assertTrue(h.slots == 35 && h.elements.length == 35);
	}
	
	/*
	 * I wanted to see if my hash table would fill up all the empty slots without the extra credit. In order to use this,
	 * Uncomment and comment the line in my put method that checks the size.
	 */
//	@Test
//	public void PutTest2() {
//		PaStringHasher ha = new PaStringHasher();
//		QuadraticHashTable h = new QuadraticHashTable(ha, 23);
//		Object Texas = new Object();
//		for(int i = 0; i < 22; i ++) {
//			h.put("Tx", Texas);
//			assertTrue(h.size() == i+1);
//		}
//		h.put("Tx", Texas);
//	}
}
