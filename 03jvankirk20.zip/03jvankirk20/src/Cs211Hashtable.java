
public interface Cs211Hashtable {
	 public int size();
	 public boolean isEmpty();
	 public Object[] values();
	 public String[] keys();
	 public Object get(String key);
	 public Object put(String key, Object element);
	 public Object remove(String key);
	 public void clear(); 
}
