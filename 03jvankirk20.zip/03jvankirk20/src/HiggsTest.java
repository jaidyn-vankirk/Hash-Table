import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class HiggsTest {

	@Rule public TestName name = new TestName();
	
	TestTable ht;

    /** Adds testing methods to students defined class to work with these JUnit tests.   Might need
        to change the visibilty of the students variables to "protected" in order to get this to work.  **/
	public class TestTable extends QuadraticHashTable {

	    /** constructor should delegate to the students constructor **/
		public TestTable(int maxArraySize, PaStringHasher hasherHelper) {
		    super(hasherHelper,maxArraySize );    //call student's constructor...with correct parameters to match student
		}		
		

	    /** getter method to return the size of the students hash table array */
		public int tableN() {
		    return elements.length;   // change to match the students array instance variable
		}
		
	    /** getter method to return a handle on the students hash table. **/
		public QuadraticHashTable.MapEntry[] getItems() {
			return elements;      // change to match the students array instance variable
		}
		
	    /** Dumps/outputs the students table to console so we can see the hash table.  If the other methods 
		above works, this method need not be altered **/ 
		public void dump(String msg) {
			
			QuadraticHashTable.MapEntry[] arr = getItems();
			
			System.out.println("\n\n"+name.getMethodName()+"----["+msg +"]----");
			System.out.println("table has "+arr.length+" slots.");
			for (int i = 0; i< arr.length; i++) {
				if (arr[i] != null)
					System.out.println(String.format("[%2d] %s -> %s ", i, arr[i].getKey(), arr[i].getValue()));
				else
					System.out.println(String.format("[%2d] - ", i));
			}
			System.out.println("\n\n----  ----");
			
		}

	    /** Returns the location (index) of the item in the students hashtable.  If the other methods 
		above works, this method need not be altered **/
		public int indexOf(String key) {
			
			QuadraticHashTable.MapEntry[] arr = getItems();
			
			for(int i=0; i<arr.length; i++) {
				if (arr[i] == null) continue;
				if (key.equals(arr[i].getKey())) return i; 
			}
			
			return -1;
		}
		
		
		
	}

	
	
    /** Runs BEFORE each an every test inorder to create a new hash table object.  We call the TestTable constructor
	which will call the student's constructor **/
	@Before
	public void setUp() throws Exception {
		
		ht = new TestTable(23, new PaStringHasher() );
	}

	
	
	@Test
	public void test_isEmpty_whenTableIsEmpty() {
		assertTrue("should be empty when new", ht.isEmpty());
	}

	
	@Test
	public void test_isEmpty_afterPutsAndRemoved() {
		
		assertTrue(ht.isEmpty());
		
		ht.put("jan","january");
		assertEquals(1,ht.size());
		assertFalse(ht.isEmpty());
	
		ht.put("feb","february");
		assertEquals(2,ht.size());
		assertFalse(ht.isEmpty());
		
		ht.dump("isEmpty after insert jan,feb");
		assertTrue("jan not found", ht.indexOf("jan")>=0 );
		assertTrue("feb not found", ht.indexOf("feb")>=0 );
		
		ht.remove("jan");
		assertEquals(1,ht.size());
		assertFalse(ht.isEmpty());
		
		ht.remove("feb");
		assertEquals(0,ht.size());
		assertTrue(ht.isEmpty());

		ht.dump("isEmpty after remove jan,feb...should be empty");
		assertFalse("jan still after remove", ht.indexOf("jan")>=0);
		assertFalse("feb present after remove ", ht.indexOf("feb")>=0);

	}
	
	
	
	@Test
	public void test_isEmpty_afterPutsAndClear() {
		
		assertTrue(ht.isEmpty());
		
		ht.put("jan","january");
		assertEquals(1,ht.size());
		assertFalse(ht.isEmpty());
	
		ht.put("feb","february");
		assertEquals(2,ht.size());
		assertFalse(ht.isEmpty());
		
		ht.clear();
		
		assertEquals(0,ht.size());
		assertTrue(ht.isEmpty());

	}
	
	
	@Test
	public void test_size_whenTableIsEmptySizeIsZero() {
		assertEquals(0,ht.size());
	}
	
	
	
	@Test
	public void test_clear_afterPutsAndRemoved() {
		
		assertPresent(ht.keys());
		
		ht.put("jan","january");
		assertEquals(1,ht.size());
	
		ht.put("feb","february");
		assertEquals(2,ht.size());
		
		ht.clear();
		
		assertPresent(ht.keys());
		
	}
	
	
	
	@Test
	public void test_size_afterPuts() {
		
		ht.put("jan","january");
		assertEquals(1,ht.size());
	
		ht.put("feb","february");
		assertEquals(2,ht.size());
	}
	
	private void assertPresent(Object[] keys, String ...vals) {
		List<String> expected = new ArrayList<>(Arrays.asList(vals));
		
		for (Object k : keys) {
			if (k == null) Assert.fail("null found in keys");
			assertTrue("unexpected key ["+k+"]",expected.contains(k));
			expected.remove(k);
		}
		assertTrue("extra keys found", expected.isEmpty());
	}
}
