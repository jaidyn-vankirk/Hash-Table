/**
 * 
 * This class creates a quadratic hash table that uses horner's rule to initially hash and then uses quadratic probing to handle collisions.
 * This class also provides helpful methods.
 * @author jaidynvankirk
 *
 */
public class QuadraticHashTable implements Cs211Hashtable{
	
	int numOfElements;									//Holds the actual number of elements in the array.
	MapEntry[] elements = new MapEntry [23];			//Creates an array that has 23 buckets.
	Hasher h;											//Holds our hasher.
	int slots = 23;										//Holds the number of slots/buckets.(Mostly for the extra credit.)
	MapEntry vacated;									//Vacated entry for when the user removes an element.
	
	/*
	 * Creates the hash table and allows the user to input there own hasher(so the hash table can be used for other things besides Strings) and
	 * allows them to set the number of slots/buckets in the the array. Also initializes a few of our variables.
	 */
	public QuadraticHashTable (Hasher h, int slots) {
		numOfElements = 0;
		elements = new MapEntry[slots];
		this.h = h;
		this.slots = slots;
		Object vacatedObject = new Object();
		vacated = new MapEntry("0000", vacatedObject);
	}
	
	/*
	 * Returns the number of elements(not the length of the table).
	 */
	public int size() {
		return numOfElements;
	}
	
	/*
	 * Returns the number of buckets.
	 */
	public int getSlots() {
		return slots;
	}

	/*
	 * Sees if the hash table is empty by looking to see if the number of elements is 0.
	 */
	public boolean isEmpty() {
		if (numOfElements == 0) {
			return true;
		}else {
			return false;
		}
	}

	/*
	 * Gets all the values by traversing the entire array.
	 */
	public Object[] values() {
		Object [] ans = new Object[numOfElements];				//Creates a new array with the number of elements int.
		int j = 0;												//Seperate counter for our ans[].
		for (int i = 0; i < slots; i++) {
			if(elements[i] != null && elements[i] != vacated) {
				ans[j] = elements[i].getValue();					//Adds the elements that aren't null or vacated to our array.
				j++;
			}
		}
		return ans;												//Returns the array.
	}

	/*
	 * Does a similar method as values(), except we get keys.
	 */
	public String[] keys() {									
		String [] ans = new String[numOfElements];
		int j = 0;
		for (int i = 0; i < slots; i++) {
			if(elements[i] != null && elements[i] != vacated) {
				ans[j] = elements[i].getKey();
				j++;
			}
		}
		return ans;
	}

	/*
	 * Traverses the hash table to find an element by using a key.
	 */
	public Object get(String key) {
		int place = h.hashKey(key, slots);					//Hashes the key.
		Object returnObj = elements[place].dataItem;
		int lastPlace = place;								//Keeps track of the number before the last test.
		if (elements[place] != null) {						//Only skips if we land on an element that is null.
			int i = 0;
			while (elements[place] != null && i < slots) {				//Stops if a slot is null. Does not stop it if it is vacant.
				lastPlace = place;
				place = (int) ((place + Math.pow(-1, (i + 1)) * Math.pow(i, 2.0)) % slots);		//Quadratic probing function.
				if(place < 0) {				//If we get a negative number, we add the number of slots, so it wraps.
					place += slots;
				}
				i ++;
			}
				returnObj = elements[lastPlace].getValue();
			return returnObj;
		} else {
			return returnObj;
		}
	}

	/*
	 * Turns the element into a MapEntry, hashes the key, and puts it into the proper spot in the array. If collision occurs, it fixes it
	 * by quadratic probing.
	 */
	public Object put(String key, Object element) {
		MapEntry newME = new MapEntry(key, element);					//New MapEntry
		int place = h.hashKey(key, slots);								//Hashes the key
		int originalPlace = place;
		if (elements[place] != null) {									//Checks to see if the slot is not null. If it is vacated or null, it does not have to do the collision method.
			for (int i = 0; i < slots; i++) {
				int beforeAddingPlace = (int) (Math.pow(-1, (i + 1)) * Math.pow(i, 2));	//Uses the quadratic probing function.
				place = originalPlace + beforeAddingPlace;
				if(place >= 0) {				//Wraps if needed.
					place %= slots;
				} else if(place == slots) {
					place = 0;
				} else {
					place = slots + (place % slots);
				}
				if(elements[place] == null || elements[place] == vacated) {
					break;
				}
			}
			elements[place] = newME;	//Once an open slot is found, it places it there.
		} else {
			elements[place] = newME;
		}
		numOfElements++;				//Increments our number of elements property.
		expandTable();					//Checks to see if the table needs expanding.
		return element;					//Returns the element that we put in the Hash Table.
	}

	/*
	 * Removes an object from the Hash Table and replaces it with the vacated MapEntry.
	 */
	public Object remove(String key) {
		int place = h.hashKey(key, slots);					//Hashes the key.
		int originalPlace = place;
		int i = 0;
		while (elements[place] == vacated && i < slots) {	//Will continue to traverse the HashTable until we reach null or an element that we can return.
			place = (int) ((originalPlace + Math.pow(-1, (i + 1)) * Math.pow(i, 2.0)) % slots);			//Quadratic Probing
			if(place < 0) {																		//Wrapping around if necessary.
				place += slots;
			}
			i ++;
		}
		if (elements[place] == null) {															//Sees if our final element is null.
			return null;																		
		} else {																				//If it is not null, we return the object, vacate the bucket, and update our numOfElements value.
			Object returnObj = elements[place].getValue();
			elements[place] = vacated;
			numOfElements--;
			return returnObj;
		}
	}

	/*
	 * Clears the array by creating a new one. Updates some of our values.
	 */
	public void clear() {
		numOfElements = 0;
		slots = 23;
		elements = new MapEntry[23];
		
	}
	
	/*
	 * Extra credit. Put calls this method to check and see if the hash table is at 60% compacity. If so, it changes the slots number to a number around 1.5 of the
	 * original slots and makes sure it is n%4=3. It then creates the new array and inserts all the old values into it.
	 */
	protected void expandTable() {
		double percFilled = (double)numOfElements/(double)slots;
		String[] keys = keys();								//Gets all of the keys.
		Object[] values = values();	
		if(percFilled >= .6) {
			slots *= 1.5;	
			int adder = 3 - (slots%4);
			slots += adder;						//Gets all of the values.
			elements = new MapEntry[slots];
			numOfElements = 0;
			for(int i = 0; i < keys.length; i ++) {
				put(keys[i], values[i]);						//Takes from both of these arrays, because they should be in the same order.
			}
		}
	}
	
	/*
	 * This object will hold our key and our object together. It also provides get methods for them.
	 */
	protected class MapEntry {
		String keyHandle;
		Object dataItem;
		
		private MapEntry(String keyHandle, Object dataItem) {
			this.keyHandle = keyHandle;
			this.dataItem = dataItem;
		}
		
		protected String getKey() {
			return keyHandle;
		}
		protected Object getValue() {
			return dataItem;
		}
	}
}
