
public interface Hasher {
	int hashKey(String key, int maxNumberOfBuckets);
}
